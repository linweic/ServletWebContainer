package edu.upenn.cis.cis455.webserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger; 

public class WorkerThread extends Thread{
	static final Logger logger = Logger.getLogger(WorkerThread.class);
	private final LinkedList<Socket> sharedQueue;
	//private final int queueSize;
	private final StringBuffer rootPath;
	public static BufferedReader incomingRequest;
	public static PrintWriter outstandingResponse;
	public static HashMap<String,ArrayList<String>> headerLines;
	public static String initialLine;
	public static String url;
	public static String httpVersion;
	public static Socket clientSocket;
	
	public WorkerThread(LinkedList<Socket> sharedQueue, String rootPath){
		this.sharedQueue = sharedQueue;
		//this.queueSize = queueSize;
		this.rootPath = new StringBuffer(rootPath);
	}
	
	public Socket readFromQueue() throws InterruptedException{
		while(sharedQueue.isEmpty()){
			synchronized(sharedQueue){
				System.out.println("Queue is empty right now.");
				sharedQueue.wait();
			}
		}
		synchronized(sharedQueue){
			sharedQueue.notifyAll();
			if(ThreadPool.isrunning == false) Thread.currentThread().interrupt();
			clientSocket = sharedQueue.removeFirst();
			return clientSocket;
		}
	}
	
	public boolean doesExist(StringBuffer s){
		Path resourceFile = Paths.get(s.toString());
		//File requestFile = new File(s.toString());
		if(Files.exists(resourceFile) == true) return true;
		else return false;
	}
	
	public boolean isAccessible(StringBuffer s){
		Path resource = Paths.get(s.toString());
		return Files.isReadable(resource);
	}
	
	public Matcher regexMatcher(String pattern, String text){
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(text);
		return m;
	}
	
	public String checkMapping(HttpServer.Handler h, String line){
		logger.info("Requested url is: " + line);
		for (String k: h.m_servletsMapping.keySet()){
			String urlPattern = h.m_servletsMapping.get(k);
			if(urlPattern.charAt(0) != '*' && urlPattern.charAt(0) != '/'){
				urlPattern = "/" + urlPattern;
			}
			logger.info("url pattern is: " + urlPattern);
			/*exact match*/
			if(line.equals(urlPattern)) return k;
			/*prefix match*/
			String wildcard = urlPattern.substring(urlPattern.length()-2);
			if(wildcard.equals("/*")){
				String servletPath = urlPattern.substring(0,urlPattern.length()-2);
				if (line.length() >= servletPath.length() && line.substring(0,servletPath.length()).equals(servletPath)) return k;
			}
			/*suffix match*/
			if(urlPattern.charAt(0) == '*'){
				int suffixLength = urlPattern.length();
				String suffix = urlPattern.substring(1, suffixLength);
				if (line.length() >= suffix.length() && line.substring(line.length()-suffixLength).equals(suffix)) return k;
			}
		}		
		return null;
	}
	public HttpSession isSessionExist() {
		if(headerLines.containsKey("Cookie".toUpperCase())){
			ArrayList<String> values = headerLines.get("Cookie".toUpperCase());
			for(String s : values){
				if(s.contains("JSESSIONID")){
					String[] strings = s.split("=");
					return HttpServer.sessions.get(strings[1]);
				}
			}
		}
		return null;
	}
	public void startServlet(String[] strings, String servletName) throws ServletException, IOException {
		/*find JSESSIONID*/
		MySession currentSession = (MySession) isSessionExist();
		MyRequest request = new MyRequest(currentSession);
		for(String k : headerLines.keySet()){
			ArrayList<String> values = headerLines.get(k);
			request.setAttribute(k, values);
		}
		request.setAttribute("ServletContext", HttpServer.context);
		request.setAttribute("ServletConfig", HttpServer.configs.get(servletName));
		request.setAttribute("ServletMapping", HttpServer.h.m_servletsMapping);
		request.setAttribute("requestURL", url);
		request.setAttribute("initialLine",initialLine);
		request.setAttribute("protocol",httpVersion);
		
		request.getQueryString();
		HttpSession hs = request.getSession(true);
		logger.info(hs.getId());
		if(hs.isNew() == true) HttpServer.sessions.put(hs.getId(), hs);
		MyResponse response = new MyResponse();
		Cookie cookie = new Cookie("JSESSIONID",hs.getId());
		response.addCookie(cookie);
		HttpServlet servlet = HttpServer.servlets.get(servletName);
		for(int i = 2; i<strings.length-2; i+=2){
			request.setParameter(strings[i],strings[i+1]);
		}
		if(strings[0].equals("GET")||strings[0].equals("POST")){
			request.setMethod(strings[0]);
			servlet.service(request,response);
		}
	}
	
	public HashMap<String, ArrayList<String>> parseHeaderLines(BufferedReader bf) throws IOException{
		HashMap<String, ArrayList<String>> headerLines = new HashMap<String,ArrayList<String>>();
		String lastKey = null;
		ArrayList<String> lastValue = new ArrayList<String>();
		String currentLine;
		while(!(currentLine=bf.readLine()).trim().equals("")){ //read header lines before blank line
			logger.debug("current header line:"+currentLine);
			String pattern = "(.*):\\s*(.*)";
			Matcher m = regexMatcher(pattern, currentLine);
			if(m.find()) { //if match a line with "header:value", put the pair into hashmap
				lastKey = m.group(1).toUpperCase();
				if(headerLines.containsKey(lastKey)){
					lastValue = headerLines.get(lastKey);
				}
				else lastValue.clear();
				String[] values = m.group(2).split(";");
				for(String s: values) lastValue.add(s);
				headerLines.put(lastKey, lastValue);
			}
			else{ //if match a line starts with space or tab, append the value to the previous value of header line
				pattern = "(\\s+|\\t+)(.*)";
				m = regexMatcher(pattern,currentLine);
				if(m.find()){
					String[] values = m.group(2).split(";");
					for(String s: values ) lastValue.add(s);
					if(lastKey != null)headerLines.put(lastKey, lastValue);
					else return null;
				}
			}
		}
		for(String k: headerLines.keySet()) logger.debug(k + ":" + headerLines.get(k));
		return headerLines;
	}
	public void processRequest(BufferedReader incomingStuff){
		System.out.println("start process");
		ResponseConstructor rc = new ResponseConstructor();
		StringBuffer messageBody = new StringBuffer();
		try{
			if((initialLine=incomingStuff.readLine())==null) //initialLine = incomingStuff.readLine(); //read the first line of request
			{
				/*bad request, no content in the request*/
				StringBuffer errResponse = rc.errHandler("HTTP/1.1","400 Bad Request","Request received as null.",
						"HTTP requests must include the status line and header:value lines.");
				outstandingResponse.print(errResponse);
				outstandingResponse.flush();
				return;
			}
			logger.info("intial line:"+ initialLine);
			
			headerLines = parseHeaderLines(incomingStuff);
			if(headerLines == null){
				StringBuffer errResponse = rc.errHandler("HTTP/1.1","400 Bad Request","No header line received.", 
						"HTTP 1.1 requests must include at least one header line before other information.");
				outstandingResponse.print(errResponse);
				outstandingResponse.flush();
				return;
			}
			
			String[] strings = initialLine.split("\\?|&|=|;|\\s");
			for (String s: strings) logger.info(s);
			httpVersion = initialLine.substring(initialLine.length()-8, initialLine.length());
			url = strings[1];
			String servletName = checkMapping(HttpServer.h, url);
			logger.info(servletName);
			if(servletName != null){
				logger.info("There is a mapping...");
				startServlet(strings, servletName);
				return;
			}
			logger.info("There is not a mapping...");
			/*
			while((currentLine = incomingStuff.readLine())!=null) { //store optional message body into messageBody variable
				//System.out.println("currentline:"+currentLine);
				messageBody.append(currentLine).append("\n");
				//System.out.println("msgbody:"+messageBody);
			}
			*/
		} catch (IOException|ServletException e){
			e.printStackTrace();
		}
		//String pattern = ".*\\s.*\\s(HTTP.*)";
		//Matcher m = regexMatcher(pattern, initialLine);
		//System.out.println("initial line:"+ initialLine);
		
		//System.out.println("httpversion:"+ httpVersion);
		/*handle special cases*/
		if(initialLine.equals("GET /shutdown "+ httpVersion)) {
			/*shutdown server*/
			ThreadPool.isrunning = false;
			System.out.println(ThreadPool.isrunning);
			outstandingResponse.print(httpVersion +" 200 OK\r\n");
			outstandingResponse.print("\r\n");
			outstandingResponse.flush();
			return;
		}
		else if(initialLine.equals("GET /control "+ httpVersion)){
			/*show up control page*/
			StringBuffer controlResponse = rc.controlHandler(httpVersion);
			outstandingResponse.print(controlResponse);
			outstandingResponse.flush();
		}
		else{
			/*process first line of the request*/
			if(initialLine.trim().equals("")) {
				/*bad request, initial line is empty*/
				StringBuffer errResponse = rc.errHandler(httpVersion,"400 Bad Request","No status line received.",
						"HTTP 1.1 requests must include the status line.");
				outstandingResponse.print(errResponse);
				outstandingResponse.flush();
				return;
				};
			String pattern = "(\\w+)\\s(.*)\\sHTTP.+";
		    Matcher m = regexMatcher(pattern, initialLine);
		    String method = null;
		    StringBuffer relativePath = null;
		    //HashMap<String,String> fileAndExtension = new HashMap<String,String>();
		    if(!m.find()) {
		    	/*bad request, initial line invalid*/
		    	StringBuffer errResponse = rc.errHandler(httpVersion,"400 Bad Request","Invalid status line received.",
						"Please make sure the HTTP request status line includes a supported HTTP method and a valid pathname.");
				outstandingResponse.print(errResponse);
				outstandingResponse.flush();
				return;
		    	}
		    method = m.group(1);
		    System.out.println("method:"+method);
		    relativePath = new StringBuffer(m.group(2));
		    System.out.println("relative path:"+ relativePath);
		    //StringBuffer fullPathname = rootPath.append(relativePath);
		    File rootDir = new File(rootPath.toString());
		    File file = new File(rootDir, relativePath.toString());
		    StringBuffer fullPathname = new StringBuffer(file.getPath());
		    System.out.println("full pathname:"+ fullPathname);
		    if((!method.equals("GET")) && (!method.equals("HEAD"))){
		    	/*501 not implemented*/
		    	StringBuffer errResponse = rc.errHandler(httpVersion, "501 Not Implemented", "HTTP method not supported", 
		    			"HTTP only supports GET and HEAD methods right now.");
		    	outstandingResponse.print(errResponse);
		    	outstandingResponse.flush();
		    	return;
		    	}
		    System.out.println(doesExist(fullPathname));
		    if(doesExist(fullPathname)==false){
		    	/*404 not found*/
		    	StringBuffer errResponse = rc.errHandler(httpVersion, "404 Not Found", "The requested resource doesn't exist", 
		    			"");
		    	outstandingResponse.print(errResponse);
		    	outstandingResponse.flush();
		    	return;
		    	}
		    
		    if(!isAccessible(fullPathname)){
		    	//401 Unauthorized
		    	StringBuffer errResponse = rc.errHandler(httpVersion, "401 Unauthorized",
		    			"The client is not authorized to get access to the resource. ", "");
		    	outstandingResponse.print(errResponse);
		    	outstandingResponse.flush();
		    	return;
		    }
		    	
		    /*the initial line is validated*/
		    /*100 Continue*/
		    if(httpVersion.equals("HTTP/1.1") && headerLines.keySet().contains("Expect")){
		    	StringBuffer interimResponse = rc.firstLineHandler();
		    	outstandingResponse.print(interimResponse);
		    	outstandingResponse.flush();
		    }
		    /*check if host header exists*/
		    System.out.println(headerLines.keySet());
		    if((!headerLines.keySet().contains("Host")) && httpVersion.equals("HTTP/1.1")){
		    	/*400 Bad request, no host header received*/
		    	StringBuffer errResponse = rc.errHandler(httpVersion, "400 Bad Request", "No Host: header received",
		    			"HTTP 1.1 requests must include the Host:header.");
		    	outstandingResponse.print(errResponse);
		    	outstandingResponse.flush();
		    	return;
		    	}
		    /*create a Path instance regarding given pathname*/
		    Path resource = null;
		    try{
		    	resource = Paths.get(fullPathname.toString());
		    }catch(InvalidPathException e){
		    	e.printStackTrace();
		    }
		    
		    /*check if the path represents a directory*/
		    try{
		    	if(Files.isDirectory(resource,LinkOption.NOFOLLOW_LINKS)){
		    		File currentDir = new File(fullPathname.toString());
		    		System.out.println(currentDir.toString());
		    		String[] fileList = currentDir.list();
		    		for (String i: fileList) System.out.println(i);
		    		/*return a page with a list of files in the directory*/
		    		StringBuffer dirResponse = rc.dirRequestHandler(httpVersion, method, fileList);
		    		//System.out.println("@@@@@@@@@@@@@@@@@@@@" + dirResponse);
		    		outstandingResponse.print(dirResponse);
		    		outstandingResponse.flush();
		    		outstandingResponse.close();
		    		//rc.dirRequestHandler(httpVersion, method, fileList, outstandingResponse);
		    		return;
		    	}
		    }catch(SecurityException e){
		    	e.printStackTrace();
		    }
			/*if the file is not a directory, determine the extension of requested file*/
			pattern = "/(\\w+)\\.(\\w+)";
			m = regexMatcher(pattern,relativePath.toString());
			String filename = null;
			String fileExtension = null;
			if(m.find()) {
				filename = m.group(1);
				fileExtension = m.group(2);
			}
			else{
				System.out.println("here");
				/*404 not found*/
				StringBuffer errResponse = rc.errHandler(httpVersion,"404 Not Found", "The requested resource doesn't exist", 
		    			"");
		    	outstandingResponse.print(errResponse);
		    	outstandingResponse.flush();
		    	return;
			}			
			try{
				/*handle If-Modified-Since request*/
				if(headerLines.containsKey("If-Modified-Since")){
					FileTime lastModified = Files.getLastModifiedTime(resource,LinkOption.NOFOLLOW_LINKS);
					String lastModified_string = lastModified.toString();
					String GMT_value = headerLines.get("If-Modified-Since").get(0);
					SimpleDateFormat sdf1 = new SimpleDateFormat();
					sdf1.applyPattern("EEE, dd MMM yyyy HH:mm:ss z");
					sdf1.setTimeZone(TimeZone.getTimeZone("GMT"));
		            Date dateOfHeader = sdf1.parse(GMT_value);
		            SimpleDateFormat sdf2 = new SimpleDateFormat();
		            sdf2.applyPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'");
		            sdf2.setTimeZone(TimeZone.getTimeZone("UTC"));
		            Date dateOfFile = sdf2.parse(lastModified_string);
		            if( dateOfHeader.compareTo(dateOfFile) == 1){
		            	/*304 Not Modified*/
		            	StringBuffer errResponse = rc.errHandler(httpVersion,"304 Not Modified", "The requested resource hasn't been modified since given date", 
				    			"The requested resource is required to be modified after given date value.");
				    	outstandingResponse.print(errResponse);
				    	outstandingResponse.flush();
				    	return;
		            	}
				}
				if(headerLines.containsKey("If-Unmodified-Since")){
					FileTime lastModified = Files.getLastModifiedTime(resource,LinkOption.NOFOLLOW_LINKS);
					String lastModified_string = lastModified.toString();
					String GMT_value = headerLines.get("If-Unmodified-Since").get(0);
					SimpleDateFormat sdf1 = new SimpleDateFormat();
					sdf1.applyPattern("EEE, dd MMM yyyy HH:mm:ss z");
					sdf1.setTimeZone(TimeZone.getTimeZone("GMT"));
		            Date dateOfHeader = sdf1.parse(GMT_value);
		            SimpleDateFormat sdf2 = new SimpleDateFormat();
		            sdf2.applyPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'");
		            sdf2.setTimeZone(TimeZone.getTimeZone("UTC"));
		            Date dateOfFile = sdf2.parse(lastModified_string);
		            if( dateOfHeader.compareTo(dateOfFile) == -1){
		            	/*412 Precondition Failed*/
		            	StringBuffer errResponse = rc.errHandler(httpVersion, "412 Precondition Failed", "The requested resource has been modified since given date", 
				    			"The requested resource is required not to be modified after given date value.");
				    	outstandingResponse.print(errResponse);
				    	outstandingResponse.flush();
				    	return;
		            	}
				}
			}catch (Exception e){
				e.printStackTrace();
			}
			try {
				rc.fileHandler(httpVersion, method, fullPathname.toString(), fileExtension, outstandingResponse);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void run(){
		while(true){
			Socket current = null;
			/*read the first socket from blocking queue*/
			try{
				current = readFromQueue();
			} catch (InterruptedException e){
				System.out.println("terminated while in waiting status");
				break;
				//continue;
			}
			logger.info("Successfully get socket");
			/*successfully get the socket, now parse the request */
			try{
				incomingRequest = new BufferedReader(new InputStreamReader(current.getInputStream()));
			}catch(IOException e){
				logger.error("IOException occurs when getInputStream() method is called");
			}
			logger.info("got input stream");
			try{
				outstandingResponse = new PrintWriter(current.getOutputStream(),false);
			}catch(IOException e){
				logger.error("IOExcetption occurs when getOutputStream() method is called.");
			}
			logger.info("Prepare to start process request.");
			processRequest(incomingRequest);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
