package edu.upenn.cis.cis455.webserver;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyResponseTest {
	MyResponse response = new MyResponse();
	@Test
	public void testMyResponse() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddCookie() {
		fail("Not yet implemented");
	}

	@Test
	public void testContainsHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testEncodeURL() {
		fail("Not yet implemented");
	}

	@Test
	public void testEncodeRedirectURL() {
		fail("Not yet implemented");
	}

	@Test
	public void testEncodeUrl() {
		fail("Not yet implemented");
	}

	@Test
	public void testEncodeRedirectUrl() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendErrorIntString() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendErrorInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendRedirect() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetDateHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddDateHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetIntHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddIntHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetStatusInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetStatusIntString() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCharacterEncoding() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetContentType() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetOutputStream() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWriter() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetCharacterEncoding() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetContentLength() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetContentType() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetBufferSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBufferSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testFlushBuffer() {
		fail("Not yet implemented");
	}

	@Test
	public void testResetBuffer() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsCommitted() {
		fail("Not yet implemented");
	}

	@Test
	public void testReset() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetLocale() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLocale() {
		fail("Not yet implemented");
	}

}
