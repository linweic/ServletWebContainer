package edu.upenn.cis.cis455.webserver;

import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DemoServlet extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
		       throws java.io.IOException
		  {
		    response.setContentType("text/html");
		    PrintWriter out = response.getWriter();
		    out.print("<html><head><title>Foo</title></head>");
		    out.print("<body>Hello World</body></html>");
		    
		    //response.flushBuffer();
		    out.close();
		  }
}
