package edu.upenn.cis.cis455.webserver;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * @author tjgreen
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MyResponse implements HttpServletResponse {
	static final Logger logger = Logger.getLogger(MyResponse.class);
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#addCookie(javax.servlet.http.Cookie)
	 */
	private HashMap<String, String> responseHeaders;
	private int statusCode;
	private int bufferSize;
	private StringBuffer buffer;
	private boolean committed;
	
	public MyResponse(){
		buffer = new StringBuffer(WorkerThread.httpVersion);
		buffer.append(" 200 OK");
		committed = false;
		responseHeaders = new HashMap<String, String>();
	}
	
	public void addCookie(Cookie arg0) {
		// TODO Auto-generated method stub
		if(isCommitted() == true) return;
		StringBuffer values = new StringBuffer(arg0.getName());
		//StringBuffer nameValue = new StringBuffer(arg0.getName());
		values.append("=").append(arg0.getValue());
		values.append("; Max-Age=").append(arg0.getMaxAge());
		values.append("; Secure=").append(arg0.getSecure());
		values.append("; Version=").append(arg0.getVersion());
		if(arg0.getComment() != null){
			values.append("; Comment=").append(arg0.getComment());
		}
		if(arg0.getDomain() != null){
			values.append("; Domain=").append(arg0.getDomain());
		}
		if(arg0.getPath() != null){
			values.append("; Path=").append(arg0.getPath());
		}
		//buffer.append("\r\nSet-Cookie: ").append(values);
		logger.info(buffer.toString());
		responseHeaders.put("Set-Cookie".toUpperCase(), values.toString());
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#containsHeader(java.lang.String)
	 */
	public boolean containsHeader(String arg0) {
		// TODO Auto-generated method stub
		if (responseHeaders.containsKey(arg0.toUpperCase())) return true;
		else return false;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#encodeURL(java.lang.String)
	 */
	public String encodeURL(String arg0) {
		return arg0;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#encodeRedirectURL(java.lang.String)
	 */
	public String encodeRedirectURL(String arg0) {
		return arg0;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#encodeUrl(java.lang.String)
	 */
	public String encodeUrl(String arg0) {
		return arg0;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#encodeRedirectUrl(java.lang.String)
	 */
	public String encodeRedirectUrl(String arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#sendError(int, java.lang.String)
	 */
	public void sendError(int arg0, String arg1) throws IOException {
		// TODO Auto-generated method stub
		if(isCommitted() == true) {
			throw new IllegalStateException(); 
		}
		else{
			PrintWriter out = getWriter();
			StringBuffer statusLine = new StringBuffer(WorkerThread.httpVersion);
			statusLine = statusLine.append(" ").append(arg0).append(" ").append(arg1);
			logger.info(statusLine);
			out.println(statusLine);
			setContentType("text/html");
			logger.info("Content-Type: text/html");
			out.println("Content-Type: text/html");
			StringBuffer msgBody = new StringBuffer();
			msgBody.append("<html><body><h2>Error:").append(arg0).append("</h2>").append(arg1).append("</body></html>");
			StringBuffer contentLength = new StringBuffer("Content-Length: ");
			logger.info(contentLength.append(msgBody.length()));
			out.println(contentLength.append(msgBody.length()));
			out.println("\r\n");
			logger.info(msgBody);
			out.println(msgBody);
			out.flush();
			committed = true;
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#sendError(int)
	 */
	public void sendError(int arg0) throws IOException {
		// TODO Auto-generated method stub
		if(isCommitted() == true){
			throw new IllegalStateException();
		}
		else{
			PrintWriter out = getWriter();
			StringBuffer statusLine = new StringBuffer(WorkerThread.httpVersion);
			statusLine = statusLine.append(" ").append(arg0);
			out.println(statusLine);
			out.flush();
			committed = true;
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#sendRedirect(java.lang.String)
	 */
	public void sendRedirect(String arg0) throws IOException {
		if(isCommitted() == true){
			throw new IllegalStateException();
		}
		else {
		System.out.println("[DEBUG] redirect to " + arg0 + " requested");
		System.out.println("[DEBUG] stack trace: ");
		Exception e = new Exception();
		StackTraceElement[] frames = e.getStackTrace();
		for (int i = 0; i < frames.length; i++) {
			System.out.print("[DEBUG]   ");
			System.out.println(frames[i].toString());
		}
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#setDateHeader(java.lang.String, long)
	 */
	public void setDateHeader(String arg0, long arg1) {
		// TODO Auto-generated method stub
		addDateHeader(arg0,arg1);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#addDateHeader(java.lang.String, long)
	 */
	public void addDateHeader(String arg0, long arg1) {
		// TODO Auto-generated method stub
		Date date = new Date(arg1);
		SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.applyPattern("EEE, dd MMM yyyy HH:mm:ss z");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        String dateString = sdf.format(date);
        responseHeaders.put(arg0.toUpperCase(), dateString);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#setHeader(java.lang.String, java.lang.String)
	 */
	public void setHeader(String arg0, String arg1) {
		// TODO Auto-generated method stub
		addHeader(arg0,arg1);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#addHeader(java.lang.String, java.lang.String)
	 */
	public void addHeader(String arg0, String arg1) {
		// TODO Auto-generated method stub
		responseHeaders.put(arg0.toUpperCase(), arg1);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#setIntHeader(java.lang.String, int)
	 */
	public void setIntHeader(String arg0, int arg1) {
		// TODO Auto-generated method stub
		addIntHeader(arg0,arg1);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#addIntHeader(java.lang.String, int)
	 */
	public void addIntHeader(String arg0, int arg1) {
		// TODO Auto-generated method stub
		String intValue = String.valueOf(arg1);
		responseHeaders.put(arg0.toUpperCase(),intValue);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#setStatus(int)
	 */
	public void setStatus(int arg0) {
		// TODO Auto-generated method stub
		statusCode = arg0;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServletResponse#setStatus(int, java.lang.String)
	 */
	public void setStatus(int arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getCharacterEncoding()
	 */
	public String getCharacterEncoding() {
		// TODO Auto-generated method stub
		return "ISO-8859-1";
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getContentType()
	 */
	public String getContentType() {
		// TODO Auto-generated method stub
		if(responseHeaders.containsKey("Content-Type".toUpperCase())){
			String type = responseHeaders.get("Content-Type".toUpperCase());
			return type;
		}
		else return "text/html";
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getOutputStream()
	 */
	public ServletOutputStream getOutputStream() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getWriter()
	 */
	public PrintWriter getWriter() throws IOException {
		if(isCommitted() == true) {
			logger.info("response has already been committed.");
			return null;
		}
		else{
			PrintWriter pw = WorkerThread.outstandingResponse;
			for(String s: responseHeaders.keySet()){
				buffer.append("\r\n").append(s).append(": ").append(responseHeaders.get(s));
			}
			pw.println(buffer);
			pw.println("\r\n");
			return pw;
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#setCharacterEncoding(java.lang.String)
	 */
	public void setCharacterEncoding(String arg0) {
		// TODO Auto-generated method stub
		if(isCommitted() == true) {
			logger.info("Response has been committed, this method has no effect.");
			return;
		}
		if(containsHeader("Content-Type".toUpperCase()) == false){
			System.err.println("No content-type has been set");
			return;
		}
		String values = responseHeaders.get("Content-Type".toUpperCase());
		String[] strings = values.split(";");
		StringBuffer sb = new StringBuffer(strings[0]);
		sb.append("; charset=").append(arg0);
		responseHeaders.put("Content-Type".toUpperCase(), sb.toString());
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#setContentLength(int)
	 */
	public void setContentLength(int arg0) {
		// TODO Auto-generated method stub
		responseHeaders.put("Content-Length".toUpperCase(), String.valueOf(arg0));
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#setContentType(java.lang.String)
	 */
	public void setContentType(String arg0) {
		// TODO Auto-generated method stub
		responseHeaders.put("Content-Type".toUpperCase(), arg0);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#setBufferSize(int)
	 */
	public void setBufferSize(int arg0) {
		// TODO Auto-generated method stub
		if(isCommitted() == true){
			throw new IllegalStateException();
		}
		else buffer = new StringBuffer(arg0);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getBufferSize()
	 */
	public int getBufferSize() {
		// TODO Auto-generated method stub
		return buffer.capacity();
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#flushBuffer()
	 */
	public void flushBuffer() throws IOException {
		// TODO Auto-generated method stub
		if(isCommitted() == true){
			throw new IllegalStateException();
		}
		else{
			getWriter().flush();
			committed = true;
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#resetBuffer()
	 */
	public void resetBuffer() {
		// TODO Auto-generated method stub
		buffer = new StringBuffer(0);  
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#isCommitted()
	 */
	public boolean isCommitted() {
		// TODO Auto-generated method stub
		return committed;
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#reset()
	 */
	public void reset() {
		// TODO Auto-generated method stub
		if(isCommitted()) throw new IllegalStateException();
		else{
			buffer.delete(0,buffer.length());
		}
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#setLocale(java.util.Locale)
	 */
	public void setLocale(Locale arg0) {
		// TODO Auto-generated method stub
		responseHeaders.put("Content-Language", arg0.getLanguage());
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletResponse#getLocale()
	 */
	public Locale getLocale() {
		// TODO Auto-generated method stub
		if(responseHeaders.containsKey("Content-Language") == false) return null;
		String language = responseHeaders.get("Content-Language");
		Locale value = new Locale(language); 
		return value;
	}

}
