package edu.upenn.cis.cis455.webserver;

import static org.junit.Assert.*;

import org.junit.Test;

public class MySessionTest {

	@Test
	public void testMySession() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCreationTime() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetId() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLastAccessedTime() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetServletContext() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetMaxInactiveInterval() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMaxInactiveInterval() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSessionContext() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAttribute() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetValue() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAttributeNames() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetValueNames() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetAttribute() {
		fail("Not yet implemented");
	}

	@Test
	public void testPutValue() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveAttribute() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveValue() {
		fail("Not yet implemented");
	}

	@Test
	public void testInvalidate() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsNew() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsValid() {
		fail("Not yet implemented");
	}

}
